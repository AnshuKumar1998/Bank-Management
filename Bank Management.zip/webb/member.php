<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" class="no-js" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title>MINI Bank > Contact</title>
	<meta name="description" content="">
	
    <!-- CSS FILES -->
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/style.css" media="screen" data-name="skins">
    <link rel="stylesheet" href="css/layout/wide.css" data-name="layout">

    <link rel="stylesheet" type="text/css" href="css/switcher.css" media="screen" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<!--Start Header-->
<header id="header">
<div id="header-top">
    <div class="container">
        
    </div>
</div>
<?php include("new_menu.php"); ?>
<section class="page_head">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <nav id="breadcrumbs">
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li>contacts</li>
                    </ul>
                </nav>

                <div class="page_title">
                    <h2>contact </h2>
                </div>
            </div>
        </div>
    </div>
</section>
</header>

<!--End Header-->

<!--start Cart Section-->
<section class="content">
    <div class="container">
        <div class="row">
            <div class="col-md-12 table-responsive">
			<?php
$conn= mysqli_connect("localhost", "root", "", "Bank");
$sql="SELECT * FROM data";

$result=mysqli_query($conn, $sql);


if(!mysqli_num_rows($result) > 0)
{
	?>  <script> alert("You Have No Data");  </script>   <?php
}
else
{
?>
                <table class="table" id="kol">
                    <thead>
                    <tr>
                        
                        <th>Sl. No</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Email</th>
                        <th>Mobile</th>
						<th>Password</th>
						
                    </tr>
                    </thead>
                    <tbody>
					<?php
while($row=mysqli_fetch_assoc($result))
{
	?>
                    <tr>
             
                        <td> <?php echo $row['SL']; ?></td>
						<td> <?php echo $row['Name']; ?></td>
						<td> <?php echo $row['Gender']; ?></td>
						<td> <?php echo substr(($row['Email']),0,3); ?> ***<?php echo substr(($row['Email']),-10,-1); ?>m</td>
						<td> <?php echo substr(($row['Mobile']),0,7); ?> ***</td>
						<td> **********</td>
                    </tr>
<?php } ?>
                    
                    </tbody>
                </table>
<?php } ?>
            </div>
        </div>


            <div class="col-md-7">
                <div class="dividerHeading">
                    <h4>
                        <span>Details</span>
                    </h4>
                </div>
                <table class="table shop-cart-total">
                    <tbody>
                    <tr>
                        <th>Total Account</th>
                        <td class="text-right"><?php echo  1+mysqli_affected_rows($conn); ?></td>
                    </tr>
					<?php
							$online="SELECT Status FROM data WHERE Status='Online'";
							
							$onresult=mysqli_query($conn, $online);
							
							?>
                    <tr>
                        <th>Current Online</th>
                        <td class="text-right"><?php echo  mysqli_affected_rows($conn); ?></td>
                    </tr>
                    <tr>
                        <th>Total</th>
                        <td class="text-right">Thank You.</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<!--end Cart Section-->
<section class="promo_box">
    <div class="container">
        <div class="row">
            <div class="col-sm-9 col-md-9 col-lg-9">
                <div class="promo_content">
                    <h3>This is the List of MINI BANK all Account Holder.</h3>
                    <p>If You Want Download PDF then Click Download Button. </p>
                </div>
            </div>
            <div class="col-sm-3 col-md-3 col-lg-3">
                <div class="pb_action">
                    <a id="#btnExport" class="btn btn-lg btn-default" href="#fakelink">
                        <i class="fa fa-shopping-cart"></i>
                       <input type="button" id="btnExport" value="Export" /> Download Now
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<!--start footer-->
<?php include("footer.php");  ?>

<!--End footer-->



<script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/retina-1.1.0.min.js"></script>
<script type="text/javascript" src="js/jquery.cookie.js"></script> <!-- jQuery cookie -->
<script type="text/javascript" src="js/styleswitch.js"></script> <!-- Style Colors Switcher -->
<script type="text/javascript" src="js/jquery.smartmenus.min.js"></script>
<script type="text/javascript" src="js/jquery.smartmenus.bootstrap.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/jflickrfeed.js"></script>
<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
<script type="text/javascript" src="js/jquery.isotope.min.js"></script>
<script type="text/javascript" src="js/swipe.js"></script>


<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
<script type="text/javascript">
        $("body").on("click", "#btnExport", function () {
            html2canvas($('#kol')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("customer-details.pdf");
                }
            });
        });
    </script>

<script type="text/javascript" src="js/jquery.sticky.js"></script>

<script src="js/main.js"></script>



<script>
    $(window).load(function(){
        $("#menu-bar").sticky({ topSpacing: 0 });
    });
</script>
</body>
</html>
