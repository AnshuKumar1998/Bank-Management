<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" class="no-js" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title>Mini Bank > Registration</title>
	<meta name="description" content="">

    <!-- CSS FILES -->
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/style.css" media="screen" data-name="skins">
    <link rel="stylesheet" href="css/layout/wide.css" data-name="layout">

    <link rel="stylesheet" type="text/css" href="css/switcher.css" media="screen" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<!--Start Header-->
<header id="header">
<div id="header-top">
    <div class="container">
        
    </div>
</div>
<?php include("new_menu.php"); ?>
<section class="page_head">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <nav id="breadcrumbs">
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li>Rgistration Page</li>
                    </ul>
                </nav>

                <div class="page_title">
                    <h2>Registration Page</h2>
                </div>
            </div>
        </div>
    </div>
</section>
</header>
<!--End Header-->
	
	<!--start wrapper-->
	<section class="wrapper">
		<section class="content contact">
			<div class="container">
				

				<div class="row sub_content">
					<div class="col-lg-8 col-md-8 col-sm-8">
						<div class="dividerHeading">
							<h4><span>Please Fill Care Fully</span></h4>
						</div>
						<p>Don't Leave any Blank Box and before the submission Check Once Again.</p>
							
						<div class="alert alert-success hidden alert-dismissable" id="contactSuccess">
						  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						  <strong>Success!</strong> Your message has been sent to us.
						</div>
						
						<div class="alert alert-error hidden" id="contactError">
						  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						  <strong>Error!</strong> There was an error sending your message.
						</div>
						
						
						<form  method="POST"  enctype="multipart/form-data">
						
						
                            <div class="row">
                                <div class="form-group">
                                    <div class="col-lg-6 ">
                                        <input type="text" id="name" name="name" class="form-control" maxlength="100" data-msg-required="Please enter your name." value="" placeholder="Your Name" >
                                    </div>
									
                                </div>
                            </div>
							<div class="row">
                                <div class="form-group">
                                   
                                    <div class="col-lg-6 ">
                                        <input type="email" id="email" name="email" class="form-control" onkeyup="emailval()" maxlength="100" data-msg-email="Please enter a valid email address." data-msg-required="Please enter your email address." value="" placeholder="Your E-mail" >
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <div class="col-lg-6">
									
                                        <input type="radio"  name="gender"  style="height:20px; width:20px; " value="Male" >&nbsp;&nbsp; Male &nbsp;&nbsp;&nbsp;&nbsp;
										<input type="radio"  name="gender" style="height:20px; width:20px;"   value="Female" >&nbsp;&nbsp;Female
									
									</div>
                                </div>
                            </div>
							<div class="row">
                                <div class="form-group">
                                    <div class="col-lg-6">
                                        <select name="occupied" class="form-control" maxlength="50" data-msg-required="Please enter the subject." value="" placeholder="Occupiation">
										<option class="form-control" maxlength="50" data-msg-required="Please enter the subject.">None</option>
										<option class="form-control" maxlength="50" data-msg-required="Please enter the subject.">MCA</option>
										</select>
									</div>
                                </div>
                            </div>
							<div class="row">
                                <div class="form-group">
                                    <div class="col-lg-6">
                                        <input type="text" id="subject" name="mobile" class="form-control" maxlength="100" data-msg-required="Please enter the subject." value="" placeholder="Mobile No.">
                                    </div>
                                </div>
                            </div>
							<div class="row">
                                <div class="form-group">
                                    <div class="col-lg-6">
                                        <input type="text" id="subject" name="amt" class="form-control" maxlength="100" data-msg-required="Please enter the subject." value="" placeholder="Amount">
                                    </div>
                                </div>
                            </div>
							<div class="row">
                                <div class="form-group">
                                    <div class="col-lg-6">
                                        <input type="Password" id="subject" name="pass" class="form-control" maxlength="100" data-msg-required="Please enter the subject." value="" placeholder="Password">
                                    </div>
                                </div>
                            </div>
							
							<div class="row">
                                <div class="form-group">
                                    <div class="col-lg-6">
                                        <input type="file" id="subject" name="image" class="form-control" maxlength="100" placeholder="Image">
                                    </div>
                                </div>
                            </div>
							
                        
                            <div class="row">
                                <div class="col-md-12">
                                    <input type="submit"  class="btn btn-default btn-lg"  name="submit">
                                </div>
                            </div>   
						</form>
						
					</div>
					<?php
					 
	

 if(isset($_POST['submit']))
 {
	 
	$conn = mysqli_connect("localhost", "root", "", "Bank");
	
	
	 $name=$_POST['name'];
	 $gender=$_POST['gender'];
	 $email=$_POST['email'];
	 $mobile=$_POST['mobile'];
	 $pass=$_POST['pass'];
	 $file_name=$_FILES['image']['name'];
	 $file_tmp=$_FILES['image']['tmp_name'];
	 $status="Offline";
	 $money=$_POST['amt'];
	 $accno=rand(6000,100000);
	
	$insertquery= "INSERT INTO data (Name, Gender, Email, Mobile, Password, Money, Status, Photo, Account) VALUES ('{$name}','{$gender}', '{$email}', '{$mobile}', '{$pass}', '{$money}', '{$status}', '{$file_name}', '{$accno}')";
	
	$resultsql = mysqli_query($conn, $insertquery);
	
	
	
	if($resultsql)
	{
		move_uploaded_file($file_tmp,"upload-image/".$file_name);
		?> <script> alert("Registration SuccessFully Done"); </script><?php 
		
		?> <script>window.open("http://localhost/webb/Login.php","_self"); </script> <?php
		
		die();
		
	
		//header("Location: http://localhost/webb/login.php");
	}
	else
	{
		?> <script> alert("somethink is Wrong"); </script><?php 
	}
	
	
 }

	

?>
					
					<div class="col-lg-4 col-md-4 col-sm-4">
						<div class="sidebar">
							<div class="widget_info">
								<div class="dividerHeading">
									<h4><span>Advertisment</span></h4>
									</div>
								<image src="dd.GIF" height="400px" width="500px;">
								
							</div>
							
							
						</div>
					</div>
					
				</div>
			</div>
		</section>
	</section>
	<!--end wrapper-->

	<!--start footer-->
    <?php include("footer.php"); ?>
	<!--end footer-->
	
	

    <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/retina-1.1.0.min.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script> <!-- jQuery cookie -->
    <script type="text/javascript" src="js/styleswitch.js"></script> <!-- Style Colors Switcher -->
    <script type="text/javascript" src="js/jquery.smartmenus.min.js"></script>
    <script type="text/javascript" src="js/jquery.smartmenus.bootstrap.min.js"></script>
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="js/jflickrfeed.js"></script>
    <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="js/jquery.isotope.min.js"></script>
    <script type="text/javascript" src="js/swipe.js"></script>

    <script type="text/javascript" src="js/jquery.validate.js"></script>
    <script type="text/javascript" src="js/view.contact.js"></script>
    <script type="text/javascript" src="js/jquery.gmap.js"></script>
    <script type="text/javascript" src="js/jquery.sticky.js"></script>

    <script src="js/main.js"></script>

   

</body>
</html>
