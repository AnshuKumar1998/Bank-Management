
<!--start footer-->
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="widget_title">
                    <h4><span>About Us</span></h4>
                </div>
                <div class="widget_content">
                    <p>We Try to Help of any those people who wants meeds money in very short time with minimum intrest without any long process.</p>
                    <ul class="contact-details-alt">
                        <li><i class="fa fa-map-marker"></i> <p><strong>Address</strong>: Bengluru</p></li>
                        <li><i class="fa fa-user"></i> <p><strong>Phone</strong>:+91 7903539817</p></li>
                        <li><i class="fa fa-envelope"></i> <p><strong>Email</strong>: <a href="#">anshumk123@gmail.com</a></p></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="widget_title">
                    <h4><span>Main Office Address</span></h4>
                </div>
                <div class="widget_content">
                    <ul class="links">
                        <li> <a href="#">Flate no 32/B<span></span></a></li>
                        <li> <a href="#">2nd Stage BTM Layout, Bengluru <span></span></a></li>
                        <li> <a href="#">City Bengluru, Karnatak<span></span></a></li>
                        <li> <a href="#">Karnatak, INDIA <span></span></a></li>
						<li> <a href="#">Pin : 560076<span></span></a></li>
                    </ul>
                </div>
            </div>
			
			
			
            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="widget_title">
                    <h4><span>Menu</span></h4>
                </div>
				
			
               <div class="widget_content" id="menuu">
                    <ul class="tweet_list">
                        <li class="tweet_content item">
                            <p class="tweet_link"><a href="terms.php">Terms & Conditions. </a> </p>
                           
                        </li>
                        <li class="tweet_content item">
                            <p class="tweet_link"><a href="Registration.php">Registration</a> </p>
                            
                        </li>
                        <li class="tweet_content item">
                            <p class="tweet_link" id="lgg"><a id="fg" href="Login.php">Log In </a> </p>
                           
                        </li>
						<li class="tweet_content item">
                            <p class="tweet_link"><a href="contact.php">Contact </a> </p>
                           
                        </li>
						<li class="tweet_content item">
                            <p class="tweet_link"><a href="news.php">News and Notice </a> </p>
                           
                        </li>
                    </ul>
                </div>
				<?php  
				$a=$_SESSION;
				
				//if($_SESSION['Name']!="")
					if(isset($_SESSION['Name']))
					{
						?>
							<script>document.getElementById("lgg").innerHTML = 'Logout';</script>	

							<script> document.getElementById("fg").href = "log.php";</script>
							<?php
					}
					
			
			
				?>
			
                <div class="widget_content">
                    <div class="tweet_go"></div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="widget_title">
                    <h4><span>MINI BANK</span></h4>
                </div>
                <div class="widget_content">
                    <div class="flickr">
                        <ul id="flickrFeed" class="flickr-feed"></ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--end footer-->
<section class="footer_bottom">
		<div class="container">
			<div class="row">
            <div class="col-sm-6">
                <p class="copyright">&copy; Copyright 2020 ProBusiness | Powered by  <a href="https://www.yahoobaba.net/">Anshu Kumar</a></p>
            </div>

            <div class="col-sm-6 ">
                <div class="footer_social">
                    <ul class="footbot_social">
                        <li><a class="fb" href="#." data-placement="top" data-toggle="tooltip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a class="twtr" href="#." data-placement="top" data-toggle="tooltip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a class="dribbble" href="#." data-placement="top" data-toggle="tooltip" title="Dribbble"><i class="fa fa-dribbble"></i></a></li>
                        <li><a class="skype" href="#." data-placement="top" data-toggle="tooltip" title="Skype"><i class="fa fa-skype"></i></a></li>
                        <li><a class="rss" href="#." data-placement="top" data-toggle="tooltip" title="RSS"><i class="fa fa-rss"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
		</div>
	</section>