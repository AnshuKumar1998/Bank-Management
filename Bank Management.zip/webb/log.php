<?php




session_start();

$conn=mysqli_connect("localhost", "root", "", "bank");
					$sql="UPDATE data SET Status='Offline' where Email='{$_SESSION["Email"]}' ";
					$result=mysqli_query($conn, $sql);
				
session_unset();
session_destroy();
?>
<script>alert("Logout Done");</script>
<?php
header("Location: http://localhost/webb/Login.php");

?>