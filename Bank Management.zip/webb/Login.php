<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" class="no-js" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Home > Log In</title>
    <meta name="description" content="">
<?php session_start(); ?>
    <!-- CSS FILES -->
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/style.css" media="screen" data-name="skins">
    <link rel="stylesheet" href="css/layout/wide.css" data-name="layout">
    <link rel="stylesheet" href="css/animate.css" type="text/css"/>

    <link rel="stylesheet" type="text/css" href="css/switcher.css" media="screen" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<!--Start Header-->
<header id="header">
<div id="header-top">
    <div class="container">
        
    </div>
</div>
<?php include("new_menu.php"); ?>
<section class="page_head">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <nav id="breadcrumbs">
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li>Log In</li>
                    </ul>
                </nav>

                <div class="page_title">
                    <h2>Log In</h2>
                </div>
            </div>
        </div>
    </div>
</section>
</header>
<!--End Header-->

<!--start Form elements-->
<section class="wrapper">
    <div class="container">
        <div class="row sub_content">
            <div class="col-lg-6 col-sm-6">
                <div class="dividerHeading">
                    <h4><span>Log In </span></h4>
                </div>
                <form method="POST">
                    <input type="text" name="email" id="name" class="form-control" placeholder="Email">
                    <input type="password" name="pass" id="email" class="form-control" placeholder="Password">
					
                    <div class="pull-right">
                        <input type="submit" value="Log In" name="submit" id="submit" class="btn btn-default btn-lg button">
						
                    </div>
					<span id="error" style="color:red;"><span>
                </form>
            </div>
            
            <div class="col-lg-6 col-sm-6">
                <div class="dividerHeading">
                    <h4><span>Advertisment</span></h4>
                </div>
                <image src="Hero.gif" width="700" height="400">
            </div>
        </div>
    </div>
</section>
<!--end Form elements-->

<?php
if(isset($_POST['submit']))
{
$user=$_POST['email'];
$pass=$_POST['pass'];

$conn=mysqli_connect("localhost", "root", "", "Bank");

$sql="SELECT * FROM data where Email='{$user}' and Password='{$pass}'";

$updatesql="UPDATE data SET Status='Online' WHERE Email='{$user}'";

$result = mysqli_query($conn, $sql);


if(mysqli_num_rows($result) == 1)
{	
		
		$sqlname="SELECT Name, Mobile FROM data where Email='{$user}'";
		
		
	$resultname = mysqli_query($conn, $sqlname);
	$row=mysqli_fetch_assoc($resultname);
	
	
	
	$_SESSION['Name']= $row["Name"];
	
	$_SESSION['Email']="$user";
	$_SESSION['Mobile']=$row["Mobile"];
	
	$res = mysqli_query($conn, $updatesql);
	
	
	?> <script>window.open("http://localhost/webb/user.php","_self"); </script> <?php
	
}
else
{
?> <script>document.getElementById("error").innerHTML="Check Email and Password"; </script><?php
}

}
?>
<!--start footer-->
<?php  include("footer.php"); ?>
<!--end footer-->



<script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/retina-1.1.0.min.js"></script>
<script type="text/javascript" src="js/jquery.cookie.js"></script> <!-- jQuery cookie -->
<script type="text/javascript" src="js/styleswitch.js"></script> <!-- Style Colors Switcher -->
<script type="text/javascript" src="js/jquery.smartmenus.min.js"></script>
<script type="text/javascript" src="js/jquery.smartmenus.bootstrap.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/jflickrfeed.js"></script>
<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
<script type="text/javascript" src="js/jquery.isotope.min.js"></script>
<script type="text/javascript" src="js/swipe.js"></script>

<script type="text/javascript" src="js/jquery.sticky.js"></script>

<script src="js/main.js"></script>


<script type="text/javascript" src="js/wow.min.js"></script>
<script>
    // WOW Animation
    new WOW().init();
</script>
<script>
    $(window).load(function(){
        $("#menu-bar").sticky({ topSpacing: 0 });
    });
</script>
</body>
</html>