<?php

$conn =mysqli_connect("localhost", "root", "", "bank");

session_start();


$sql="SELECT * FROM data where Email='{$_SESSION['Email']}' ";
	$result =mysqli_query($conn, $sql);
	$row=mysqli_fetch_assoc($result);

$Useracnum=$_POST['userpost'];
$ownacnum=$row['Account'];
$Amount=$_POST['amt'];



	$a=intval($row['Money']);
	
	
	if($a>=$Amount)
	{
	
	$name=$row['Name'];
	$email=$row['Email'];
	$mobile=$row['Mobile'];
	
	$curmoney=$a-$Amount;
	$purpose="Transfer";
	
	$date=date("d.m.Y");
	$status="Send";
	
	$ownsql="UPDATE data SET Money='$curmoney' where Account='$ownacnum'";
		// $ownres=mysqli_query($conn, $ownsql);
		
	$payinsert="INSERT INTO payment (Name, Email, Mobile, Purpose, Amount, Status ,Txtnumber) VALUES ('{$name}', '{$email}', '{$mobile}', '{$purpose}', '{$Amount}', '{$status}' , '{$date}')";
	if(mysqli_query($conn, $payinsert) && mysqli_query($conn, $ownsql))
	{
		
	}
	else
	{
		
	}
	
	
	$sql="Select * from data where Account ='$Useracnum' ";
	$result =mysqli_query($conn, $sql);
	$row=mysqli_fetch_assoc($result);
	
	$name=$row['Name'];
	$email=$row['Email'];
	$mobile=$row['Mobile'];
	$a=intval($row['Money']);
	$curmoney=$Amount + $a;

	$purpose="Transfer";
	$ownacnum=$_POST['userpost'];
	$date=date("d.m.Y");
	$status="Recived";
	
	$ownsql="UPDATE data SET Money='$curmoney' where Account='$ownacnum'";
		// $ownres=mysqli_query($conn, $ownsql);
		
	$payinsert="INSERT INTO payment (Name, Email, Mobile, Purpose, Amount, Status, Txtnumber) VALUES ('{$name}', '{$email}', '{$mobile}', '{$purpose}', '{$Amount}','{$status}' , '{$date}' )";
	if(mysqli_query($conn, $payinsert) && mysqli_query($conn, $ownsql))
	{
		
	}
	else
	{
		
	}
	
	echo "Transfer SuccessFully Send";
	}
	else
	{
			echo "Low Balance";
	}


	
	

?>