 <!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" class="no-js" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Home</title>
    <meta name="description" content="">

    <!-- CSS FILES -->
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="css/flexslider.css"/>
    <link rel="stylesheet" type="text/css" href="css/style.css" media="screen" data-name="skins">
    <link rel="stylesheet" href="css/layout/wide.css" data-name="layout">

    <link rel="stylesheet" href="css/animate.css"/>

    <link rel="stylesheet" type="text/css" href="css/switcher.css" media="screen" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body class="home">
    <header id="header">
        <!-- Start header-top -->
        <div id="header-top">
            <div class="container">

            </div>
        </div>
        <!--/.header-top -->
		
<?php include("new_menu.php"); ?>
        
        <!--/#menu-bar -->
        <div class="slider_block">
            <div class="flexslider top_slider">
                <ul class="slides">
                    <li class="slide1">
                        <div class="container">
                            <div class="flex_caption1">

                                <p class="slide-heading FromTop">MINI BANK </p><br/>

                                <p class="sub-line FromBottom">New Way to Invest Money and Save For Future. </p><br/>

                                
                            </div>
                            <div class="flex_caption2 FromRight"></div>
                        </div>
                    </li>

                    <li class="slide2">
                        <div class="container">
                            <div class="slide flex_caption1">
                                <p class="slide-heading FromTop">Welcome, In Mini Bank</p><br/>

                                <p class="sub-line FromRight">This is Trusted and Secure Bank. </p><br/>

                               

                            </div>
                            <div class="flex_caption2 FromBottom"></div>
                        </div>
                    </li>

                    <li class="slide3">
                        <div class="container">
                            <div class="slide flex_caption1">
                                <p class="slide-heading FromTop">MINI BANK </p><br/>

                                <p class="sub-line FromRight">Easy To Use and Easy To Investment </p><br/>

                               

                            </div>
                            <div class="flex_caption2 FromRight"></div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </header>
<!--End Header-->


<section class="wrapper">
<!--start info service-->
    <section class="info_service">
        <div class="container">
            <div class="row sub_content">
                <div class="col-lg-12 col-md-12 col-sm-12 wow fadeInDown">
                    <h1 class="intro text-center">Welcome, In MINI BANK </h1>
                    <p class="lead text-center">New Way For Invest Money and Make a profit. Withdraw Process is Very Fast in some Step. If You need loan, we provide loan with minimum intrest. So Many Offer Avaliable for new Users. </p>
                </div>
                <div class="rs_box  wow bounceInRight" data-wow-offset="200">
                    <div class="col-md-3 col-sm-6">
                        <div class="serviceBox_3">
                            <div class="service-icon">
                                <i class="fa fa-globe"></i>
                            </div>
                            <div class="service-content">
                                <h3>Loan</h3>
                                <p>
                                    We Provide Loan with Minimum Intrest and extend Function are also Avaliable.
                                </p>
                            </div>
                            <div class="read">
                                <a href="#">read more...</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6">
                        <div class="serviceBox_3">
                            <div class="service-icon">
                                <i class="fa fa-rocket"></i>
                            </div>
                            <div class="service-content">
                                <h3>Money Transfer</h3>
                                <p>
                                    You Send Money with any friend and Transfer Money In Other Bank.
                                </p>
                            </div>
                            <div class="read">
                                <a href="#">read more...</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6">
                        <div class="serviceBox_3">
                            <div class="service-icon">
                                <i class="fa fa-mobile"></i>
                            </div>
                            <div class="service-content">
                                <h3>Security</h3>
                                <p>
                                    Our Network and all Data are Fully Safe and Secure. We use Indepently. 
                                </p>
                            </div>
                            <div class="read">
                                <a href="#">read more...</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6">
                        <div class="serviceBox_3">
                            <div class="service-icon">
                                <i class="fa fa-twitter"></i>
                            </div>
                            <div class="service-content">
                                <h3>Account</h3>
                                <p>
                                   Many Offers are avaliable for new users and make many Money with this Bank.
                                </p>
                            </div>
                            <div class="read">
                                <a href="#">read more...</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!--end info service-->



<section class="feature_bottom">
        <div class="container">
            <div class="row sub_content">
			<div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="dividerHeading">
                    <h4><span>Events</span></h4>
                </div>

                <div class="testimonial carousel slide" id="testimonial-carousel">
                    <div class="carousel-inner">
                        <div class="active item">
                            <div class="testimonial-item">
                                <div class="icon"><i class="fa fa-quote-right"></i></div>
                                <blockquote>
                                    <p> Our Bank Give Loan with 0 Intrest. This Offer will be stay until end of this Month. <b style="color:red">T & C Apply.</b></p>
                                </blockquote>
                                <div class="icon-tr"></div>
                                <div class="testimonial-review">
                                    
                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="testimonial-item">
                                <div class="icon"><i class="fa fa-quote-right"></i></div>
                                <blockquote>
                                    <p>This Month Loan Details and Other Details is Avaliable In our website.</p>
                                </blockquote>
                                <div class="icon-tr"></div>
                                <div class="testimonial-review">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-buttons"><a data-slide="prev" href="#testimonial-carousel"><i class="fa fa-chevron-left"></i></a>
                        <a data-slide="next" href="#testimonial-carousel"><i class="fa fa-chevron-right"></i></a></div>
                </div>
                <br/>
                <a href="https://www.yahoobaba.net/lab/testimonials-showcase/" class="btn btn-default">More Testimonial Style</a>
            </div><!-- TESTIMONIALS END -->
        </div>
                <div class="col-lg-6  wow slideInLeft" data-wow-duration="1s">
                    <div class="dividerHeading">
                        <h4><span>Why Choose Us?</span></h4>
                    </div>
                    <p></p>
                    <ul class="list_style circle">
                        <li><a href="#"> Fastest Service 24*7.</a></li>
						 <li><a href="#"> We Have Best Member for working.</a></li>
                        <li><a href="#"> We work with Only Trusted Customer.</a></li>
						 <li><a href="#"> Our Bank Alway use New Technology for approach Any work. </a></li>
                        <li><a href="#"> We Try Make More Benifit and give Best pricee of you Price.</a></li>
                        
                    </ul>
                </div>
				
				<?php
				$conn=mysqli_connect("localhost", "root", "", "bank");
				
				$sql="SELECT Money, Name FROM data ORDER BY Money DESC LIMIT 3;";
				
				$result=mysqli_query($conn, $sql);
				?>
				
				

                <!-- TESTIMONIALS -->
                <div class="col-lg-6 wow slideInRight" data-wow-duration="1s">
                    <div class="dividerHeading">
                        <h4><span>Our Top 3 Best Customer Name of This Month</span></h4>
                    </div>
					
			
                    <ul class="progress-skill-bar mrg-0" style="line-height: 45px;">
					<?php
					
					
					while($row=mysqli_fetch_all($result))
				{
					
				?>
                        <li >
      
                            <div class="progress_skill">
                                <div class="alert alert-success alert-dismissable">
                        Top 1.&nbsp;&nbsp;&nbsp;<strong><?php echo $row[0][1]; ?></strong><br> 
					
								</div>
					
                            </div>
							
                        </li>
                        
                        <li>
                           
                            <div class="progress_skill">
                                <div class="alert alert-info alert-dismissable">
                       Top 2.&nbsp;&nbsp;&nbsp; <strong ><?php echo $row[1][1];  ?></strong>  
                    </div>
                            </div>
                        </li>
                        
                        <li>
                             <div class="progress_skill">
                              <div class="alert alert-warning alert-dismissable">
                       Top .3 &nbsp;&nbsp;&nbsp;<strong ><?php echo $row[2][1]; ?></strong>  
								</div>
								</div>
					  </li>
                            
                      
                    </ul>
					<?php 
				}
				
				
				?>
                </div><!-- TESTIMONIALS END -->
            </div>
        </div>
    </section>



<!-- Parallax with Testimonial -->
    <section class="parallax parallax-1">
        <div class="container">
            <!--<h2 class="center">Testimonials</h2>-->
            <div class="row">
                <div id="parallax-testimonial-carousel" class="parallax-testimonial carousel wow fadeInUp">
                    <div class="carousel-inner">
                        <div class="active item">
                            <div class="parallax-testimonial-item">
                                <blockquote>
                                    <p>Donec convallis, metus nec tempus aliquet, nunc metus adipiscing leo, a lobortis nisi dui ut odio. Nullam ultrices, eros accumsan vulputate faucibus, turpis tortor dictum.</p>
                                </blockquote>
                                <p>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </p>
                                <div class="parallax-testimonial-review">
                                    <img src="images/testimonials/1.png" alt="testimonial">
                                    <span>Jonathan Dower</span>
                                    <small>Company Inc.</small>
                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="parallax-testimonial-item">
                                <blockquote>
                                    <p>Metus aliquet tincidunt metus, sit amet mattis lectus sodales ac. Suspendisse rhoncus dictum eros, ut egestas eros luctus eget. Nam nibh sem, mattis et feugiat ut, porttitor nec risus.</p>
                                </blockquote>
                                <p>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </p>
                                <div class="parallax-testimonial-review">
                                    <img src="images/testimonials/2.png" alt="testimonial">
                                    <span>Jonathan Dower</span>
                                    <small>Leopard</small>
                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="parallax-testimonial-item">
                                <blockquote>
                                    <p>Nunc aliquet tincidunt metus, sit amet mattis lectus sodales ac. Suspendisse rhoncus dictum eros, ut egestas eros luctus eget. Nam nibh sem, mattis et feugiat ut, porttitor nec risus.</p>
                                </blockquote>
                                <p>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </p>
                                <div class="parallax-testimonial-review">
                                    <img src="images/testimonials/3.png" alt="testimonial">
                                    <span>Jonathan Dower</span>
                                    <small>Leopard</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <ol class="carousel-indicators">
                        <li data-slide-to="0" data-target="#parallax-testimonial-carousel" class=""></li>
                        <li data-slide-to="1" data-target="#parallax-testimonial-carousel" class="active"></li>
                        <li data-slide-to="2" data-target="#parallax-testimonial-carousel" class=""></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
<!-- end : Parallax with Testimonial -->

    

    <section class="team">
        <div class="container">
            <div class="row  sub_content">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="dividerHeading">
                        <h4><span>Meet the Team</span></h4>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="team-item-content">
                        <img src="images/teams/anshu.jpg" alt="profile img">
                        <div class="team-info centered">
                            <h5>Anshu Kumar</h5>
                            <small>
                               Hi, I Am Anshu Kumar student of MCA. I am the Admin of This website. I have 3 Year Experince of website Developer.
                            </small>
                            <ul class="team-social">
                                <li>
                                    <a href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-google-plus"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="team-item-content">
                        <img src="images/teams/sejal.jpg" alt="profile img">
                        <div class="team-info centered">
                            <h5>Sejal Shaw</h5>
                            <small>
                                Hey, I am Sejal Shaw Graphic Design, I have 5 year Experience of Graphic Designing and i have already make many Design for many websites. 
                            </small>
                            <ul class="team-social">
                                <li>
                                    <a href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-google-plus"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="team-item-content">
                        <img src="images/teams/Suraj.jpg" alt="profile img">
                        <div class="team-info centered">
                            <h5>Suraj Kumar</h5>
                            <small>
                               I am Suraj Kumar. My work is make a secure all data and make fastest website.
                            </small>
                            <ul class="team-social">
                                <li>
                                    <a href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-google-plus"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="team-item-content">
                        <img src="images/teams/kajal.jpg" alt="profile img">
                        <div class="team-info centered">
                            <h5>Kajal Shaw</h5>
                            <small>
                               I am Kajal Kumari. I am the Helper for all department and other part of this website i am also tester.
                            </small>
                            <ul class="team-social">
                                <li>
                                    <a href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-google-plus"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="clients">
        <div class="container">
            <div class="row sub_content">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="dividerHeading">
                        <h4><span>Our Clients</span></h4>

                    </div>

                    <div class="our_clients">
                        <ul class="client_items clearfix">
                            <li class="col-sm-3 col-md-3 col-lg-3"><a href="services.html"  data-placement="bottom" data-toggle="tooltip" title="Client 1" ><img src="images/clients/1.png" alt="" /></a></li>
                            <li class="col-sm-3 col-md-3 col-lg-3"><a href="services.html" data-placement="bottom" data-toggle="tooltip" title="Client 2" ><img src="images/clients/2.png" alt="" /></a></li>
                            <li class="col-sm-3 col-md-3 col-lg-3"><a href="services.html" data-placement="bottom" data-toggle="tooltip" title="Client 3" ><img src="images/clients/3.png" alt="" /></a></li>
                            <li class="col-sm-3 col-md-3 col-lg-3"><a href="services.html" data-placement="bottom" data-toggle="tooltip" title="Client 4" ><img src="images/clients/4.png" alt="" /></a></li>
                        </ul><!--/ .client_items-->
                    </div>
                </div>
            </div>
        </div>
    </section>
    
</section><!--end wrapper-->

<!--start footer-->
<?php include("footer.php"); ?>
<!--end footer-->



<script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/retina-1.1.0.min.js"></script>
<script type="text/javascript" src="js/jquery.cookie.js"></script> <!-- jQuery cookie -->
<script type="text/javascript" src="js/styleswitch.js"></script> <!-- Style Colors Switcher -->
<!--
<script src="js/jquery.fractionslider.js" type="text/javascript" charset="utf-8"></script>
-->
<script type="text/javascript" src="js/jquery.smartmenus.min.js"></script>
<script type="text/javascript" src="js/jquery.smartmenus.bootstrap.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/jflickrfeed.js"></script>
<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
<script type="text/javascript" src="js/jquery.isotope.min.js"></script>
<script type="text/javascript" src="js/swipe.js"></script>

<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="js/jquery.sticky.js"></script>

<script src="js/main.js"></script>




    <script>
        $('.flexslider.top_slider').flexslider({
            animation: "fade",
            controlNav: false,
            directionNav: true,
            prevText: "&larr;",
            nextText: "&rarr;"
        });
    </script>

    <!-- WARNING: Wow.js doesn't work in IE 9 or less -->
    <!--[if gte IE 9 | !IE ]><!-->
        <script type="text/javascript" src="js/wow.min.js"></script>
        <script>
            // WOW Animation
            new WOW().init();
        </script>
    <![endif]-->

</body>
</html>