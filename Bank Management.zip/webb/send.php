<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<?php session_start();
$conn=mysqli_connect("localhost", "root", "", "bank");
					$sql="SELECT * FROM data where Email='{$_SESSION['Email']}' ";
					$result=mysqli_query($conn, $sql);
					$row=mysqli_fetch_assoc($result); ?>
</head>

<body>
<div>
<form method="POST">
<table>
<tr>
<td>User Account</td>
<td><input type="text" id="user_acc" name="user_acc" ></td>
</tr>
<tr>
<td>My Account</td>
<td><input type="text" id="own_acc" name="own_acc" ></td>
</tr>
<tr>
<td>Amount</td>
<td><input type="text" id="acc" name="acc" ></td>
</tr>
<td>Virtual ID</td>
<td><input type="text" id="a" name="a"  value="<?=(intval($row['Account'])); ?>"><td>
</tr>
<tr>

<td><button type="submit" name="transsubmit" onclick="mytrans()" >click here</button></td>
</tr>
</table>

</form>

</div>
</body>
<script>
function mytrans()
{		var us=<?php echo $row['Account']?>;
document.write(us);
	
	var useracc=document.getElementById("user_acc").value;
	var ownacc=document.getElementById("own_acc").value;
	var amtt=document.getElementById("acc").value;
		document.write(useracc);
	
	$.ajax({
		url: 'transaction.php', 
		type: 'POST', 
		data: {userpost : useracc, ownpost : ownacc, amt : amtt}, 
		success: function(result){
		//$('#loaddata').html(result);
		alert(result);
		
	}
	});
	alert("data send");
	
}
						
</script>





