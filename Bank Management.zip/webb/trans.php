<?php

$conn =mysqli_connect("localhost", "root", "", "bank");

$accid=$_POST['datapost'];


	$sql="insert into payment () where Account ='$accid' ";
	
	$result =mysqli_query($conn, $sql);
	$row=mysqli_fetch_assoc($result);
	
	
	
	
	
	
	
	
	
	
	
	
	if($row)
	{
	
	
	
	
	echo "<script>document.getElementById('accno').style.borderColor = 'green'</script>";
	echo "<script>document.getElementById('tamt').disabled =false </script>";
	
	
	}
	else
	{
		echo "Sorry..........";
		echo "<script>document.getElementById('accno').style.borderColor = 'red'</script>";
		echo "<script>document.getElementById('tamt').disabled =true </script>";
	}
	


?>