<?php

$conn =mysqli_connect("localhost", "root", "", "bank");

$accid=$_POST['datapost'];


	$sql="Select * from data where Account ='$accid' ";
	
	$result =mysqli_query($conn, $sql);
	$row=mysqli_fetch_assoc($result);
	if($row)
	{
	echo "<h3>Name : ". $row['Name']. "</h3>";
	
	echo "<h3>Gender : ". $row['Gender']. "</h3>";
	
	echo "<h3>Status : ". $row['Status']. "</h3>";
	
	echo "<h3>Mobile No. ".substr(($row['Mobile']),0,7)." ***</h3>";
	
	
	echo "<script>document.getElementById('accno').style.borderColor = 'green'</script>";
	echo "<script>document.getElementById('tamt').disabled =false </script>";
	
	
	}
	else
	{
		echo "Sorry..........";
		echo "<script>document.getElementById('accno').style.borderColor = 'red'</script>";
		echo "<script>document.getElementById('tamt').disabled =true </script>";
	}
	


?>