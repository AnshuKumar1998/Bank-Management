 <?php session_start(); ?>
 <!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" class="no-js" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Home</title>
    <meta name="description" content="">

    <!-- CSS FILES -->
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/style.css">
    
    <link rel="stylesheet" type="text/css" href="css/style.css" media="screen" data-name="skins">
    <link rel="stylesheet" href="css/layout/wide.css" data-name="layout">

    <link rel="stylesheet" href="css/animate.css"/>

    <link rel="stylesheet" type="text/css" href="css/switcher.css" media="screen" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
 

 <div id="menu-bar">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-3">
                        <div id="logo">
                            <h1><a href="index.php"><img src="images/logo_copy.png"/></a></h1>
                        </div>
                    </div>
                    <!-- Navigation
                    ================================================== -->
                    <div class="col-lg-9 col-sm-9 navbar navbar-default navbar-static-top container" role="navigation">
                        <!--  <div class="container">-->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>


 <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php"><span class="data-hover"data-hover="home">Home</span></a>
                             
                        </li>

                        <li><a href="terms.php"><span class="data-hover" data-hover="Condition">Terms & Conditions</span></a>
                            
                        </li>
							
							    <li id="memlist" style="display:none"><a href="mem.php"><span class="data-hover" data-hover="Member's">Member's</span></a>
                            
                        </li>

                       

                        <li><a href="news.php"><span class="data-hover" data-hover="News">News & Notice</span></a>
                            
                        </li>

                        <li><a href="#"><span class="data-hover" data-hover="Account">Account</span></a>
                            <ul class="dropdown-menu">
                                
                                <li><a  id="fgg" href="Registration.php"><p id="ggd" >For Register</p></a></li>
								<li ><a  id="fg" href="Login.php"><p id="dd">For Sign In</p></a></li>
								
                            </ul>
                        </li>
                        <li><a href="contact.php"> <span class="data-hover" data-hover="contact">Contact</span></a>
                            <ul class="dropdown-menu">
                                <li><a href="contact_1.html">For Bank Manager</a></li>
                                <li><a href="contact_2.html">For Admin</a></li>
                                <li><a href="contact_3.html">Local Police</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
				</div>
             </div>
        </div>
            <!--/.container -->
    </div>
				<?php 
				
						
				//if($_SESSION['Name']!="")
					if(isset($_SESSION['Name']))
					{
						?>
							<script>document.getElementById("ggd").innerHTML = 'Account';  </script>
							<script> document.getElementById("fgg").href = "user.php";</script>
							<script>document.getElementById("dd").innerHTML = 'Logout';  </script>
								
							 
							<script> document.getElementById("fg").href = "log.php";</script>
							<script> document.getElementById("memlist").style.display = "block";</script>
							 <?php 	
					}
					
			
			
				?>
				
				 